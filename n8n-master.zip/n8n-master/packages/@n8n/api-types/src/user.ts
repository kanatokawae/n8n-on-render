export type MinimalUser = {
	id: string;
	email: string;
	firstName: string;
	lastName: string;
};
